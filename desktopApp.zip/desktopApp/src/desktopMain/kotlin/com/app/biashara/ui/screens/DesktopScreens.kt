package com.app.biashara.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.*
import androidx.navigation.compose.*
import com.app.biashara.ui.screens.*

sealed class AppScreen(
    val route: String,
    val title: String,
    val icon: ImageVector
) {
    object Dashboard : AppScreen("dashboard", "Dashboard", Icons.Default.Dashboard)
    object Inventory : AppScreen("inventory", "Inventory", Icons.Default.Inventory)
    object Orders : AppScreen("orders", "Orders", Icons.Default.ShoppingCart)
    object Customers : AppScreen("customers", "Customers", Icons.Default.People)
    object Expenses : AppScreen("expenses", "Expenses", Icons.Default.Receipt)
    object Payments : AppScreen("payments", "Payments", Icons.Default.Payments)
    object Reports : AppScreen("reports", "Reports", Icons.Default.BarChart)
    object Tax : AppScreen("tax", "Tax", Icons.Default.AccountBalance)
    object KRA : AppScreen("kra", "KRA", Icons.Default.Gavel)
    object Social : AppScreen("social", "Social", Icons.Default.Forum)
    object Settings : AppScreen("settings", "Settings", Icons.Default.Settings)
}

private val appScreens = listOf(
    AppScreen.Dashboard,
    AppScreen.Inventory,
    AppScreen.Orders,
    AppScreen.Customers,
    AppScreen.Expenses,
    AppScreen.Payments,
    AppScreen.Reports,
    AppScreen.Tax,
    AppScreen.KRA,
    AppScreen.Social,
    AppScreen.Settings
)

@Composable
fun Biashara360DesktopApp() {

    val navController = rememberNavController()

    MaterialTheme {

        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        Text("Biashara360")
                    }
                )
            }
        ) { padding ->

            Row(
                Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {

                NavigationRail {

                    val currentRoute =
                        navController
                            .currentBackStackEntryAsState()
                            .value
                            ?.destination
                            ?.route

                    appScreens.forEach { screen ->

                        NavigationRailItem(
                            selected = currentRoute == screen.route,
                            onClick = {
                                navController.navigate(screen.route) {
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = {
                                Icon(screen.icon, null)
                            },
                            label = {
                                Text(screen.title)
                            }
                        )
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = AppScreen.Dashboard.route,
                    modifier = Modifier.weight(1f)
                ) {

                    composable(AppScreen.Dashboard.route) {
                        DesktopDashboardScreen()
                    }

                    composable(AppScreen.Inventory.route) {
                        DesktopInventoryScreen()
                    }

                    composable(AppScreen.Orders.route) {
                        DesktopOrdersScreen()
                    }

                    composable(AppScreen.Customers.route) {
                        DesktopCustomersScreen()
                    }

                    composable(AppScreen.Expenses.route) {
                        DesktopExpensesScreen()
                    }

                    composable(AppScreen.Payments.route) {
                        DesktopPaymentsScreen()
                    }

                    composable(AppScreen.Reports.route) {
                        DesktopReportsScreen()
                    }

                    composable(AppScreen.Tax.route) {
                        DesktopTaxScreen()
                    }

                    composable(AppScreen.KRA.route) {
                        DesktopKraScreen()
                    }

                    composable(AppScreen.Social.route) {
                        DesktopSocialScreen()
                    }

                    composable(AppScreen.Settings.route) {
                        DesktopSettingsScreen()
                    }
                }
            }
        }
    }
}