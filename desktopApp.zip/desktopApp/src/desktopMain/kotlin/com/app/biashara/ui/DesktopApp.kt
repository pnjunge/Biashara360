package com.app.biashara.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.shadow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.ui.graphics.Brush
import androidx.compose.material3.*
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.app.biashara.UserSession
import com.app.biashara.domain.model.User
import com.app.biashara.domain.model.UserRole
import kotlinx.datetime.Clock
import com.app.biashara.presentation.viewmodel.AuthViewModel
import com.app.biashara.presentation.viewmodel.AuthStep
import com.app.biashara.ui.screens.*
import com.app.biashara.ui.theme.*

sealed class DesktopScreen(val label: String, val icon: ImageVector) {
    object Dashboard : DesktopScreen("Dashboard", Icons.Filled.Home)
    object Pos : DesktopScreen("Point of Sale", Icons.Filled.Storefront)
    object Inventory : DesktopScreen("Inventory", Icons.Filled.Inventory)
    object Orders : DesktopScreen("Orders", Icons.Filled.ShoppingCart)
    object Customers : DesktopScreen("Customers", Icons.Filled.People)
    object Expenses : DesktopScreen("Expenses", Icons.Filled.Receipt)
    object Payments : DesktopScreen("Payments", Icons.Filled.AccountBalance)
    object CyberSource : DesktopScreen("CyberSource Settings", Icons.Filled.CreditCard)
    object Tax : DesktopScreen("Tax", Icons.Filled.Percent)
    object Kra : DesktopScreen("KRA iTax", Icons.Filled.Description)
    object Social : DesktopScreen("Social Inbox", Icons.Filled.Forum)
    object Reports : DesktopScreen("Reports", Icons.Filled.BarChart)
    object Settings : DesktopScreen("Settings", Icons.Filled.Settings)
}

val navItems = listOf(
    DesktopScreen.Dashboard,
    DesktopScreen.Pos,
    DesktopScreen.Inventory,
    DesktopScreen.Orders,
    DesktopScreen.Customers,
    DesktopScreen.Expenses,
    DesktopScreen.Payments,
    DesktopScreen.CyberSource,
    DesktopScreen.Tax,
    DesktopScreen.Kra,
    DesktopScreen.Social,
    DesktopScreen.Reports
)

@Composable
fun Biashara360DesktopApp() {
    val authViewModel: AuthViewModel = remember { inject() }
    val userSessionState by UserSession.currentUser.collectAsState()

    Biashara360DesktopTheme {
        if (userSessionState == null) {
            DesktopAuthFlow(authViewModel)
        } else {
            var currentScreen by remember { mutableStateOf<DesktopScreen>(DesktopScreen.Dashboard) }

            Row(Modifier.fillMaxSize()) {
                // ── Sidebar ──────────────────────────────────────────────────────
                DesktopSidebar(
                    currentScreen = currentScreen,
                    onScreenSelected = { currentScreen = it }
                )

                // ── Main Content ─────────────────────────────────────────────────
                Column(
                    Modifier.fillMaxSize().background(B360Surface)
                ) {
                    // Top bar
                    DesktopTopBar(currentScreen)
                    // Screen content
                    AnimatedContent(targetState = currentScreen) { screen ->
                        when (screen) {
                            is DesktopScreen.Dashboard -> DesktopDashboardScreen()
                            is DesktopScreen.Pos -> DesktopPosScreen()
                            is DesktopScreen.Inventory -> DesktopInventoryScreen()
                            is DesktopScreen.Orders -> DesktopOrdersScreen()
                            is DesktopScreen.Customers -> DesktopCustomersScreen()
                            is DesktopScreen.Expenses -> DesktopExpensesScreen()
                            is DesktopScreen.Payments -> DesktopPaymentsScreen()
                            is DesktopScreen.CyberSource -> DesktopCyberSourceSettingsScreen()
                            is DesktopScreen.Tax -> DesktopTaxScreen()
                            is DesktopScreen.Kra -> DesktopKraScreen()
                            is DesktopScreen.Social -> DesktopSocialScreen()
                            is DesktopScreen.Reports -> DesktopReportsScreen()
                            is DesktopScreen.Settings -> DesktopSettingsScreen()
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DesktopSidebar(currentScreen: DesktopScreen, onScreenSelected: (DesktopScreen) -> Unit) {
    val user by UserSession.currentUser.collectAsState()

    Column(
        Modifier
            .width(240.dp)
            .fillMaxHeight()
            .background(B360SidebarBg.copy(alpha = 0.85f))
            .padding(vertical = 16.dp)
    ) {
        // Logo
        Row(
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(B360Green),
                contentAlignment = Alignment.Center
            ) {
                Text("B360", color = Color.White, fontWeight = FontWeight.Black, fontSize = 11.sp)
            }
            Column {
                Text("Biashara360", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp, letterSpacing = (-0.5).sp)
                Text("Business Management", color = Color.White.copy(0.45f), fontSize = 10.sp)
            }
        }

        HorizontalDivider(color = Color.White.copy(0.08f), modifier = Modifier.padding(vertical = 12.dp))

        // Nav items
        Column(
            modifier = Modifier.weight(1f).padding(horizontal = 4.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            navItems.forEach { screen ->
                SidebarItem(
                    screen = screen,
                    isSelected = currentScreen == screen,
                    onClick = { onScreenSelected(screen) }
                )
            }
        }

        HorizontalDivider(color = Color.White.copy(0.08f), modifier = Modifier.padding(vertical = 12.dp))

        // Settings
        SidebarItem(
            screen = DesktopScreen.Settings,
            isSelected = currentScreen == DesktopScreen.Settings,
            onClick = { onScreenSelected(DesktopScreen.Settings) }
        )

        Spacer(Modifier.height(8.dp))

        // User profile (Click to Sign Out)
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .clip(RoundedCornerShape(8.dp))
                .clickable { UserSession.clearUser() }
                .padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    Modifier.size(38.dp).clip(CircleShape).background(B360Green),
                    contentAlignment = Alignment.Center
                ) {
                    Text(user?.name?.firstOrNull()?.toString()?.uppercase() ?: "W", color = Color.White, fontWeight = FontWeight.Bold)
                }
                Column {
                    Text(user?.name ?: "Wanjiru Kamau", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Text("Admin", color = Color.White.copy(0.45f), fontSize = 11.sp)
                }
            }
            Icon(
                Icons.Filled.ExitToApp,
                contentDescription = "Sign Out",
                tint = Color.White.copy(0.45f),
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
fun SidebarItem(screen: DesktopScreen, isSelected: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(
        targetValue = if (isSelected) B360SidebarSelected else Color.Transparent,
        animationSpec = tween(durationMillis = 150)
    )
    val contentColor by animateColorAsState(
        targetValue = if (isSelected) Color.White else Color.White.copy(0.6f),
        animationSpec = tween(durationMillis = 150)
    )

    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 2.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(bg)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (isSelected) {
            Box(Modifier.width(3.dp).height(20.dp).clip(RoundedCornerShape(2.dp)).background(B360Green))
        } else {
            Spacer(Modifier.width(3.dp))
        }
        Icon(screen.icon, contentDescription = null, tint = contentColor, modifier = Modifier.size(18.dp))
        Text(screen.label, color = contentColor, fontSize = 14.sp, fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal)
    }
}

@Composable
fun DesktopTopBar(currentScreen: DesktopScreen) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(brush = Brush.horizontalGradient(listOf(B360Green, B360Blue)))
            .shadow(elevation = 4.dp)
            .padding(horizontal = 24.dp, vertical = 16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(currentScreen.label, fontWeight = FontWeight.Bold, fontSize = 22.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = "",
                onValueChange = {},
                placeholder = { Text("Search...", fontSize = 13.sp) },
                leadingIcon = { Icon(Icons.Filled.Search, null, modifier = Modifier.size(18.dp)) },
                modifier = Modifier.width(280.dp).height(44.dp),
                shape = RoundedCornerShape(10.dp),
                singleLine = true
            )
            IconButton(onClick = {}) {
                BadgedBox(badge = { Badge { Text("3") } }) {
                    Icon(Icons.Filled.Notifications, null)
                }
            }
        }
    }
    HorizontalDivider(color = Color(0xFFF0F0F0))
}

@Composable
fun DesktopAuthFlow(viewModel: AuthViewModel) {
    val state by viewModel.state.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(B360Surface),
        contentAlignment = Alignment.Center
    ) {
        when (val step = state.step) {
            is AuthStep.Login -> {
                DesktopLoginCard(viewModel, state)
            }
            is AuthStep.Otp -> {
                DesktopOtpCard(viewModel, state, step.userId)
            }
        }
    }
}

@Composable
fun DesktopLoginCard(viewModel: AuthViewModel, state: com.app.biashara.presentation.viewmodel.AuthState) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .width(460.dp)
            .padding(16.dp),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(8.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(
            modifier = Modifier.padding(32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header Logo
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(B360Green),
                contentAlignment = Alignment.Center
            ) {
                Text("B360", color = Color.White, fontWeight = FontWeight.Black, fontSize = 14.sp)
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Welcome to Biashara360", fontWeight = FontWeight.Bold, fontSize = 22.sp, color = Color(0xFF0F172A))
                Spacer(Modifier.height(4.dp))
                Text("Enterprise Management Platform", color = Color.Gray, fontSize = 12.sp)
            }

            Spacer(Modifier.height(8.dp))

            val errorText = state.error
            if (errorText != null) {
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Error, null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                        Text(errorText, color = MaterialTheme.colorScheme.error, fontSize = 13.sp, modifier = Modifier.weight(1f))
                        IconButton(onClick = { viewModel.dismissError() }, modifier = Modifier.size(16.dp)) {
                            Icon(Icons.Filled.Close, null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(12.dp))
                        }
                    }
                }
            }

            OutlinedTextField(
                value = email,
                onValueChange = { email = it; viewModel.dismissError() },
                label = { Text("Email / Username") },
                leadingIcon = { Icon(Icons.Filled.Email, null, tint = B360Green, modifier = Modifier.size(18.dp)) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                singleLine = true,
                enabled = !state.isLoading
            )

            OutlinedTextField(
                value = password,
                onValueChange = { password = it; viewModel.dismissError() },
                label = { Text("Password") },
                leadingIcon = { Icon(Icons.Filled.Lock, null, tint = B360Green, modifier = Modifier.size(18.dp)) },
                trailingIcon = {
                    IconButton({ passwordVisible = !passwordVisible }) {
                        Icon(if (passwordVisible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, null, modifier = Modifier.size(18.dp))
                    }
                },
                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                singleLine = true,
                enabled = !state.isLoading
            )

            Spacer(Modifier.height(8.dp))

            Button(
                onClick = { viewModel.login(email, password) },
                modifier = Modifier.fillMaxWidth().height(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = B360Green),
                shape = RoundedCornerShape(8.dp),
                enabled = !state.isLoading && email.isNotBlank() && password.isNotBlank()
            ) {
                if (state.isLoading) {
                    CircularProgressIndicator(Modifier.size(20.dp), color = Color.White)
                } else {
                    Text("Sign In", fontWeight = FontWeight.Bold)
                }
            }

            // High-End Demo Mode Bypass
            OutlinedButton(
                onClick = {
                    UserSession.setUser(
                        User(
                            id = "wanjiru_kamau_id",
                            name = "Wanjiru Kamau",
                            email = "wanjiru@biashara360.co.ke",
                            phone = "+254712345678",
                            role = UserRole.ADMIN,
                            businessId = "default_biz_id",
                            createdAt = Clock.System.now()
                        )
                    )
                },
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = B360Green),
                border = BorderStroke(1.dp, B360Green.copy(0.3f))
            ) {
                Icon(Icons.Filled.PlayArrow, null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(8.dp))
                Text("Use Offline Demo Session", fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
fun DesktopOtpCard(viewModel: AuthViewModel, state: com.app.biashara.presentation.viewmodel.AuthState, userId: String) {
    var otp by remember { mutableStateOf("") }
    var selectedChannel by remember { mutableStateOf("SMS") }

    Card(
        modifier = Modifier
            .width(460.dp)
            .padding(16.dp),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(8.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(
            modifier = Modifier.padding(32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Filled.Security, null, tint = B360Green, modifier = Modifier.size(48.dp))

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Two-Factor Authentication", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Color(0xFF0F172A))
                Spacer(Modifier.height(4.dp))
                Text("Enter the 6-digit OTP code to continue", color = Color.Gray, fontSize = 12.sp)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("SMS", "Email").forEach { ch ->
                    FilterChip(
                        selected = selectedChannel == ch,
                        onClick = { selectedChannel = ch },
                        label = { Text(ch) },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = B360Green.copy(0.12f), selectedLabelColor = B360Green),
                        enabled = !state.isLoading
                    )
                }
            }

            val errorText = state.error
            if (errorText != null) {
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        errorText,
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(12.dp),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }

            OutlinedTextField(
                value = otp,
                onValueChange = { if (it.length <= 6) otp = it.filter { c -> c.isDigit() } },
                label = { Text("6-Digit OTP") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                singleLine = true,
                enabled = !state.isLoading
            )

            Button(
                onClick = { viewModel.verifyOtp(otp, selectedChannel) },
                modifier = Modifier.fillMaxWidth().height(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = B360Green),
                shape = RoundedCornerShape(8.dp),
                enabled = otp.length == 6 && !state.isLoading
            ) {
                if (state.isLoading) {
                    CircularProgressIndicator(Modifier.size(20.dp), color = Color.White)
                } else {
                    Text("Verify & Authenticate", fontWeight = FontWeight.Bold)
                }
            }

            val cooldown = state.otpCooldownSeconds
            TextButton(
                onClick = { if (cooldown == 0) viewModel.resendOtp() },
                enabled = cooldown == 0 && !state.isLoading
            ) {
                Text(
                    if (cooldown > 0) "Resend OTP in ${cooldown}s" else "Resend OTP",
                    color = if (cooldown > 0) Color.Gray else B360Green
                )
            }

            TextButton(onClick = { viewModel.goBackToLogin() }) {
                Text("Back to Sign In", color = Color.Gray)
            }
        }
    }
}

